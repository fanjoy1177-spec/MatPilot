"""The same deterministic service is used by Harness, CLI and evaluations."""
from __future__ import annotations

import importlib.metadata
import hashlib
from collections import Counter
import json
import platform
import shutil
import time
from pathlib import Path

from . import __version__
from .adapters import ADAPTERS
from .adapters.mattergen import canonical_hash
from .config import Settings
from .store import Store
from .worker import launch_worker, verified_records
from .requirements import audit_requirements, contract as requirement_contract
from .evidence import compare_metrics, screen_records
from .capabilities import cards
from .repairs import repair_options
from .recommendations import recommend_candidates as recommend_records


class Service:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.store = Store(settings.data_dir)

    def get_capabilities(self) -> dict:
        return {"product": "MatPilot", "version": __version__, "models": cards(self.settings),
                "backend": self.settings.backend, "max_samples": self.settings.max_samples,
                "default_samples": min(16, self.settings.max_samples), "seed_supported": self.settings.seed_supported,
                "requirements_contract": requirement_contract(),
                "candidate_recommendation": {
                    "tool": "recommend_candidates", "max_candidates": 256, "default_limit": 12,
                    "collection_ids": sorted(self.settings.candidate_collections),
                    "sources": "Choose exactly one existing job_id or operator-registered collection_id; arbitrary paths are not accepted.",
                    "method": "Verified CIFs, explicit composition and occupancy checks, structural representatives and equal-weight composition/space-group/site-bin coverage.",
                    "scope": "Read-only postprocessing and compute planning, not material-property optimization; collection provenance is independent of the current generation backend.",
                    "registration_notice": "Listed collection IDs are configured sources; manifest and CIF checksums are reverified when used."},
                "request_example": {"raw_request": "Fe-Ni-O，最多4个",
                    "model_id": "mattergen", "conditions": {"chemical_system": "Fe-Ni-O"},
                    "requirements": requirement_contract()["example"]["requirements"], "review_targets": [],
                    "num_samples": min(4, self.settings.max_samples), "batch_size": min(2, self.settings.max_samples),
                    "seed": 42, "unconditional": False, "clarifications": []},
                "input_format": {"chemical_system": "A hyphen-separated string such as Fe-Ni-O, never an array or fixed formula.",
                    "numeric_condition": {"value": 1200, "unit": "meV", "relation": "target"},
                    "review_targets": "A list of strings; these are unverified research goals, not generation conditions."},
                "planning_rules": [
                    "Copy the complete user request into raw_request; retain every constraint and research goal.",
                    "An unverified research goal may stay in review_targets without blocking an otherwise valid plan, unless the user requires it as a guaranteed condition.",
                    "Use clarifications only for genuinely missing, conflicting or ambiguous required information. Do not ask for optional numerical targets that the user did not request.",
                    "Only query a job_id actually returned by submit_job. A plan_id is not a job_id; a failed submission creates no usable job identifier."],
                "demo_notice": "Demo uses fixed NaCl fixtures, not MatterGen or AI-generated results." if self.settings.backend == "demo" else None,
                "workflow": "prepare_plan -> show conditions, review_targets and budget -> submit_job with explicit user authorization -> get_job -> screen_candidates -> optional recommend_candidates -> build_report"}

    def prepare_plan(self, request: dict) -> dict:
        model_id = request.get("model_id", "mattergen") if isinstance(request, dict) else "mattergen"
        if model_id not in ADAPTERS:
            raise ValueError(f"Unknown model {model_id!r}; installed: {list(ADAPTERS)}")
        plan = ADAPTERS[model_id].validate(request, self.settings.max_samples, self.settings)
        requirement_audit = audit_requirements(request, plan)
        plan.update({k: v for k, v in requirement_audit.items() if k != "issues"})
        plan["issues"].extend(requirement_audit["issues"])
        plan["schema_version"] = 2
        plan["state"] = "blocked" if any(i["code"] != "clarification_required" for i in plan["issues"]) else "needs_clarification" if plan["issues"] else "ready"
        plan["sampling_budget"] = {"max_samples": plan["num_samples"], "valid_candidates_target": plan.get("valid_candidates_target"), "target_guaranteed": False}
        plan["execution_context"] = {"backend": self.settings.backend,
            "config_hash": canonical_hash(self.settings.snapshot()),
            "seed_will_be_applied": self.settings.seed_supported and self.settings.backend != "demo",
            "notice": "Fixed demonstration fixtures; no generation." if self.settings.backend == "demo" else
                      "Installed MatterGen does not accept a seed; exact structure reproduction is not promised." if not self.settings.seed_supported else
                      "Seed applied; reproducibility still depends on software, hardware and weights."}
        plan["repair_options"] = repair_options(plan)
        plan["execution_context"]["real_compute_enabled"] = self.settings.real_compute_enabled
        plan["plan_id"] = canonical_hash({k: v for k, v in plan.items() if k != "plan_id"})
        return self.store.put_plan(plan)

    def submit_job(self, plan_id: str, idempotency_key: str, approved_plan_id: str) -> dict:
        plan = self.store.plan(plan_id)
        if plan["state"] != "ready":
            raise ValueError("Resolve all plan issues before submitting. No conditions are discarded automatically.")
        if approved_plan_id != plan_id:
            raise ValueError("Approval must refer to this exact plan_id.")
        if plan.get("execution_context", {}).get("config_hash") != canonical_hash(self.settings.snapshot()):
            raise ValueError("Execution configuration changed. Prepare and review a new plan before submitting.")
        if self.settings.backend != "demo" and not self.settings.real_compute_enabled:
            raise ValueError("Real scientific computation is disabled; planning and demo checks remain available.")
        if plan["model_id"] == "diffcsp" and plan.get("template"):
            from .templates import resolve_template
            if resolve_template(plan["template_id"], self.settings) != plan["template"]:
                raise ValueError("Template changed after approval. Prepare and review a new plan.")
        job, created = self.store.create_job(plan, idempotency_key, self.settings.backend, self.settings.snapshot())
        if created:
            try:
                launch_worker(self.store.root)
            except OSError as exc:
                self.store.update(job["job_id"], status="failed", error=f"Worker could not start: {exc}")
                raise ValueError("Worker could not start. Inspect the job and resume after fixing the environment.") from exc
        return {**self.get_job(job["job_id"]), "deduplicated": not created}

    def get_job(self, job_id: str) -> dict:
        job = self.store.job(job_id)
        public = {k: v for k, v in job.items() if k != "settings"}
        if job["status"] == "running" and time.time() - job.get("heartbeat", job["updated_at"]) > 30:
            public["diagnostic"] = "Worker heartbeat is late. Execution status is uncertain; do not start a duplicate job. Inspect worker.log and the process before recovery."
        public["scientific_status"] = "unvalidated_candidates"
        public["target_samples"] = self.store.plan(job["plan_id"])["num_samples"]
        public["sampling_attempts_charged"] = sum(b.get("sampling_charge", b["count"]) for b in job["batches"])
        public["sampling_budget_remaining"] = max(0, public["target_samples"] - public["sampling_attempts_charged"])
        return public

    def control_job(self, job_id: str, action: str) -> dict:
        if action == "resume" and self.store.job(job_id)["backend"] != "demo" and not self.settings.real_compute_enabled:
            raise ValueError("Real scientific computation is disabled.")
        if action == "resume":
            verified_records(self.store.job(job_id))
        self.store.control(job_id, action)
        if action == "resume":
            try:
                launch_worker(self.store.root)
            except OSError as exc:
                self.store.update(job_id, status="failed", error=f"Worker could not start: {exc}")
                raise
        return self.get_job(job_id)

    def get_results(self, job_id: str) -> dict:
        job = self.store.job(job_id)
        records = verified_records(job)
        versions = {r["candidate_id"]: self.store.structure_versions(r["candidate_id"]) for r in records}
        metrics = {v["structure_version_id"]: self.store.metrics(v["structure_version_id"])
                   for candidate_versions in versions.values() for v in candidate_versions}
        return {"job_id": job_id, "status": job["status"], "provenance": job["provenance"],
                "records": records, "count": len(records),
                "structure_versions": versions, "metrics_by_structure_version": metrics,
                "scientific_status": "unvalidated_candidates; stored metric evidence is version-specific, not proof of material performance"
                    if any(metrics.values()) else "structural_sanity_only; properties not measured"}

    @staticmethod
    def _validate_metric_selections(selections: list[dict], minimum: int, maximum: int) -> None:
        fields = {"job_id", "candidate_id", "structure_version_id", "metric_id"}
        if (not isinstance(selections, list) or not minimum <= len(selections) <= maximum
                or any(not isinstance(x, dict) or set(x) != fields
                       or any(not isinstance(v, str) or not v for v in x.values()) for x in selections)):
            raise ValueError(f"Provide {minimum} to {maximum} explicit metric selections, each with job_id, candidate_id, structure_version_id and metric_id.")
        if len({tuple(x[k] for k in sorted(fields)) for x in selections}) != len(selections):
            raise ValueError("Metric selections must not contain duplicates.")

    @staticmethod
    def _resolve_metric_selections(selections: list[dict], results_by_job: dict) -> list[dict]:
        """Shared job/candidate/version/metric binding for comparison and checks."""
        selected = []
        for selection in selections:
            job_id, candidate_id, version_id, metric_id = (selection[k] for k in
                ("job_id", "candidate_id", "structure_version_id", "metric_id"))
            result = results_by_job.get(job_id, {})
            versions = result.get("structure_versions", {}).get(candidate_id, [])
            version = next((v for v in versions if v["structure_version_id"] == version_id), None)
            if version is None or version["candidate_id"] != candidate_id or version["job_id"] != job_id:
                raise ValueError("Selected job, candidate and structure version do not match available archived evidence.")
            matches = [m for m in result["metrics_by_structure_version"][version_id] if m["metric_id"] == metric_id
                       and m["candidate_id"] == candidate_id and m["structure_version_id"] == version_id]
            if len(matches) != 1:
                raise ValueError("Selected metric does not belong to the explicit candidate and structure version.")
            selected.append(matches[0])
        return selected

    def screen_candidates(self, job_id: str, metric_selections: list[dict] | None = None) -> dict:
        result = self.get_results(job_id)
        plan = self.store.plan(self.store.job(job_id)["plan_id"])
        metrics = {r["structure_version_id"]: result["metrics_by_structure_version"][r["structure_version_id"]] for r in result["records"]}
        audit = None
        if metric_selections is not None:
            self._validate_metric_selections(metric_selections, 1, 80)
            selected = self._resolve_metric_selections(metric_selections, {job_id: result})
            choices = {}
            for metric in selected:
                version_id, prop = metric["structure_version_id"], metric["property"]
                if version_id not in metrics:
                    raise ValueError("Screening selections support original generated structure versions only.")
                if not any(r["kind"] in {"numeric_target", "numeric_bound"} and r["property"] == prop
                           and r["normalized_unit"] == metric["unit"] for r in plan["requirements"]):
                    raise ValueError("Selected metric must match a numerical requirement's property and unit.")
                key = (version_id, prop)
                if key in choices:
                    raise ValueError("Choose only one metric per candidate structure version and property.")
                choices[key] = metric
            for version_id, available in metrics.items():
                metrics[version_id] = [m for m in available if (version_id, m["property"]) not in choices]
                metrics[version_id].extend(m for (version, _), m in choices.items() if version == version_id)
            normalized = sorted((dict(x) for x in metric_selections), key=lambda x: tuple(x[k] for k in
                ("job_id", "candidate_id", "structure_version_id", "metric_id")))
            chosen_ids = {m["metric_id"] for m in selected}
            audit = {"scope": "original_generated_versions_only", "selections": normalized,
                     "selection_sha256": canonical_hash(normalized), "selected_metric_ids": sorted(chosen_ids),
                     "unselected_metric_ids": sorted(m["metric_id"] for values in result["metrics_by_structure_version"].values()
                         for m in values if m["metric_id"] not in chosen_ids),
                     "interpretation": "Checks use the explicitly selected evidence for its property. Unselected properties retain default checks. A pass is limited to the chosen method/metric; incomplete evidence remains unknown and no universal material property is established."}
        screened = screen_records(plan, result["records"], metrics)
        target = plan.get("valid_candidates_target")
        response = {**result, **screened, "metrics_by_structure_version": metrics,
                "screening_version_scope": "original_generated_versions_only",
                "valid_candidates_target": target,
                "valid_target_met": screened["unique_valid_candidate_count"] >= target if target is not None else None,
                "method": "CIF parsing, per-requirement three-valued checks, SHA256 identity and tolerance-defined pymatgen structure matching"}
        if audit is not None:
            response.update(metric_selection_audit=audit,
                            all_metrics_by_structure_version=result["metrics_by_structure_version"])
        return response

    @staticmethod
    def _recommendation_elements(plan: dict) -> list[str]:
        from pymatgen.core import Composition, Element
        conditions = plan.get("conditions", {})
        system = conditions.get("chemical_system")
        if isinstance(system, str) and system:
            try:
                return sorted({Element(value).symbol for value in system.split("-")})
            except (ValueError, TypeError) as exc:
                raise ValueError("Task chemical_system does not define valid expected elements.") from exc
        formula = conditions.get("chemical_formula")
        if isinstance(formula, str) and formula:
            try:
                return sorted(element.symbol for element in Composition(formula).elements)
            except (ValueError, TypeError) as exc:
                raise ValueError("Task chemical_formula does not define valid expected elements.") from exc
        raise ValueError("Recommendation needs an explicit chemical_system or chemical_formula in the task plan; expected elements cannot be guessed from candidates.")

    @staticmethod
    def _recommendation_view(recommendation: dict, source: dict, include_all_records: bool) -> dict:
        if type(include_all_records) is not bool:
            raise ValueError("include_all_records must be boolean.")
        records = recommendation["records"]
        counts = Counter(reason for row in records for reason in row["exclusion_reasons"])
        selected = sorted((row for row in records if row["selected"]), key=lambda row: row["selection_rank"])
        return {**recommendation, "source": source,
                "all_candidate_audit_sha256": canonical_hash(records),
                "excluded_reason_counts": dict(sorted(counts.items())),
                "unselected_qualified_count": sum(row["qualified"] and not row["selected"] for row in records),
                "include_all_records": include_all_records,
                "records": records if include_all_records else selected}

    def _load_candidate_collection(self, collection_id: str) -> tuple[dict, dict]:
        if not isinstance(collection_id, str) or collection_id not in self.settings.candidate_collections:
            raise ValueError("Unknown candidate collection; choose a registered collection_id from get_capabilities.")
        registration = self.settings.candidate_collections[collection_id]
        manifest_path = Path(registration["manifest_path"])
        if not manifest_path.is_absolute():
            if not self.settings.config_path:
                raise ValueError("Relative collection manifest paths need an operator config_path.")
            manifest_path = Path(self.settings.config_path).parent / manifest_path
        with manifest_path.open("rb") as handle:
            content = handle.read(8 * 1024 * 1024 + 1)
        if len(content) > 8 * 1024 * 1024:
            raise ValueError("Candidate manifest exceeds 8 MiB.")
        digest = hashlib.sha256(content).hexdigest()
        if digest != registration["manifest_sha256"]:
            raise ValueError("Candidate collection manifest SHA256 mismatch.")
        manifest = json.loads(content.decode("utf-8-sig"))
        required = {"schema_version", "expected_elements", "provenance", "records"}
        allowed = required | {"priority_candidate_ids", "priority_selection_basis"}
        if (not isinstance(manifest, dict) or not required <= set(manifest) or set(manifest) - allowed
                or type(manifest["schema_version"]) is not int or manifest["schema_version"] != 1
                or not isinstance(manifest["expected_elements"], list) or not manifest["expected_elements"]
                or not isinstance(manifest["provenance"], (str, dict)) or not manifest["provenance"]
                or not isinstance(manifest["records"], list) or not 1 <= len(manifest["records"]) <= 256
                or not all(isinstance(row, dict) for row in manifest["records"])):
            raise ValueError("Invalid registered candidate manifest schema.")
        for row in manifest["records"]:
            if isinstance(row.get("path"), str) and not Path(row["path"]).is_absolute():
                row["path"] = str((manifest_path.parent / row["path"]).resolve())
        return manifest, {"kind": "registered_collection", "collection_id": collection_id,
                          "manifest_sha256": digest, "provenance": manifest["provenance"],
                          "scope": "Existing archived candidates; current generation backend does not establish their provenance."}

    def recommend_candidates(self, job_id: str | None = None, collection_id: str | None = None,
                             limit: int = 12, include_all_records: bool = False) -> dict:
        """Read-only candidate planning from one known job or registered collection."""
        if (job_id is None) == (collection_id is None):
            raise ValueError("Provide exactly one job_id or collection_id.")
        if job_id is not None:
            if not isinstance(job_id, str) or not job_id:
                raise ValueError("job_id must be a nonempty string.")
            screened = self.screen_candidates(job_id)
            plan = self.store.plan(self.store.job(job_id)["plan_id"])
            recommendation = recommend_records(screened["records"], self._recommendation_elements(plan), limit)
            source = {"kind": "job", "job_id": job_id, "provenance": screened["provenance"]}
        else:
            manifest, source = self._load_candidate_collection(collection_id)
            recommendation = recommend_records(manifest["records"], manifest["expected_elements"], limit,
                priority_candidate_ids=manifest.get("priority_candidate_ids"),
                priority_selection_basis=manifest.get("priority_selection_basis"))
        return self._recommendation_view(recommendation, source, include_all_records)

    def compare_runs(self, job_ids: list[str], metric_selections: list[dict] | None = None) -> dict:
        minimum = 1 if metric_selections is not None else 2
        if (not isinstance(job_ids, list) or not minimum <= len(job_ids) <= 10
                or any(not isinstance(x, str) or not x for x in job_ids) or len(set(job_ids)) != len(job_ids)):
            raise ValueError(f"Provide {minimum} to 10 distinct job ids.")
        if metric_selections is not None:
            self._validate_metric_selections(metric_selections, 2, 20)
        jobs = [self.store.job(x) for x in job_ids]
        plans = [self.store.plan(x["plan_id"]) for x in jobs]
        provenances = {x["provenance"] for x in jobs}
        if metric_selections is None:
            if len(provenances) != 1:
                raise ValueError("Demo and real generation must not be compared as model performance.")
        elif not (provenances == {"demonstration_fixture"}
                  or provenances <= {"mattergen_execution", "diffcsp_execution"}):
            raise ValueError("Explicit metric comparison cannot mix demo and real generation or use unknown provenance.")
        comparable = all((p["model_id"], p["conditions"], p["num_samples"], p["checkpoint"], p.get("template"), p.get("requirements")) ==
                         (plans[0]["model_id"], plans[0]["conditions"], plans[0]["num_samples"], plans[0]["checkpoint"], plans[0].get("template"), plans[0].get("requirements")) for p in plans)
        rows, available_results = [], {}
        for job in jobs:
            results = self.screen_candidates(job["job_id"])
            rows.append({"job_id": job["job_id"], "status": job["status"], "count": results["count"],
                "basic_checks_pass": sum(x["basic_checks_pass"] for x in results["records"]),
                "execution_seconds": job.get("execution_seconds")})
            if metric_selections is not None:
                # Fetch every version's bound evidence, without changing the
                # generated-candidate counts or the default screening selection.
                full_results = self.get_results(job["job_id"])
                available_results[job["job_id"]] = full_results
        result = {"same_task": comparable, "rows": rows,
                "interpretation": "Descriptive workflow comparison only. Different hardware, versions, seeds and checkpoints confound speed and quality comparisons; this is not evidence of AI benefit."}
        if metric_selections is not None:
            selected = self._resolve_metric_selections(metric_selections, available_results)
            result.update(metric_selections=metric_selections, selected_metrics=selected,
                          metric_comparison=compare_metrics(selected))
        return result

    def build_report(self, job_id: str, metric_selections: list[dict] | None = None,
                     recommendation_limit: int | None = None) -> dict:
        job = self.store.job(job_id)
        plan = self.store.plan(job["plan_id"])
        result = self.screen_candidates(job_id, metric_selections)
        folder = self.store.root / "reports" / job_id
        if metric_selections is not None:
            folder = folder / "metric-selections" / result["metric_selection_audit"]["selection_sha256"]
        recommendation = None
        if recommendation_limit is not None:
            recommendation = self._recommendation_view(
                recommend_records(result["records"], self._recommendation_elements(plan), recommendation_limit),
                {"kind": "job", "job_id": job_id, "provenance": result["provenance"]}, True)
            folder = folder / "recommendations" / str(recommendation_limit)
        folder.mkdir(parents=True, exist_ok=True)
        packages = {}
        for name in ["matpilot-core", "mcp", "pymatgen"]:
            try:
                packages[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                packages[name] = "unknown"
        evidence = {"schema_version": 2, "plan": plan, "job": self.get_job(job_id), "screening": result,
                    "events": self.store.events(job_id), "environment": {"python": platform.python_version(), "platform": platform.platform(), "packages": packages},
                    "limitations": ["Execution completion is not validation of material performance.", "AI effectiveness and user time savings require a separate controlled study."]}
        if recommendation is not None:
            evidence["recommendation"] = recommendation
        json_path = folder / "evidence.json"
        json_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
        lines = ["# 材策 MatPilot 任务报告", "", f"任务编号：{job_id}", f"执行状态：{job['status']}",
                 f"数据来源：{job['provenance']}", "", "## 研究需求", str(plan["raw_request"]), "",
                 "## 执行条件", f"模型：{plan['model_id']} / {plan['checkpoint']}",
                 "```json", json.dumps(plan["conditions"], ensure_ascii=False, indent=2), "```", "",
                 f"已收集 {result['count']} 个可解析结构；最大采样预算 {plan['num_samples']}。",
                 f"计入预算的采样尝试：{self.get_job(job_id)['sampling_attempts_charged']}（含已启动但失败的批次）。",
                 f"通过基础检查和全部硬性结果要求：{result['valid_candidate_count']} 个文件；结构匹配去重后：{result['unique_valid_candidate_count']} 个。",
                 f"结构等价检查结果未知：{result['equivalence_unknown_count']} 个。",
                 f"合格候选目标：{result.get('valid_candidates_target')}；目标是否达到：{result.get('valid_target_met')}。", "",
                 "## 仍需验证的研究目标"]
        lines += [f"- {x}" for x in plan["review_targets"]] or ["未另行指定。"]
        lines += ["", "## 结果边界", "本报告只说明任务执行和结构基本检查情况。生成条件是目标值，不是测得的材料性质；未进行热力学、催化、耐腐蚀或实验性能验证。",
                  "示例模式使用固定样本，不构成真实生成或 AI 效果证据。人工操作时间与 AI 增益须通过独立对照实验评估。", "",
                  "## 候选结构", "", "| 候选 ID | 结构版本 | 文件 | 化学式 | 硬性要求均通过 | 等价候选 ID |", "|---|---|---|---|---|---|"]
        for r in result["records"]:
            lines.append(f"| {r['candidate_id']} | {r['structure_version_id']} | {Path(r['path']).name} | {r['formula']} | {r['all_hard_requirements_pass']} | {r['equivalent_to_candidate_id'] or '-'} |")
        lines += ["", "## 逐项要求与证据", "", "程序映射覆盖不等于原文语义完整；需独立复核。未配置评价方法的性质保持 unknown。",
                  "", "| 候选 ID | 要求 ID | 判定 | 观察值 | 方法或未知原因 |", "|---|---|---|---|---|"]
        def cell(value):
            return str(value).replace("|", "\\|").replace("\n", " ")
        for r in result["records"]:
            for check in r["requirement_checks"]:
                lines.append("| " + " | ".join(cell(check[k]) for k in ("candidate_id", "requirement_id", "status", "observed")) + " | " + cell(check["method"] or check["reason"]) + " |")
        if metric_selections is not None:
            audit = result["metric_selection_audit"]
            lines += ["", "## 显式指标选择", "", "本次判定仅适用于所选方法和指标；未选指标仍完整保留在 JSON 证据中。未知元数据不会因被选中而变成已验证，示例数据不构成真实材料性质结论。",
                      f"选择记录校验值：{audit['selection_sha256']}", "",
                      "| 候选 ID | 结构版本 | 所选指标 ID |", "|---|---|---|"]
            lines += ["| " + " | ".join(cell(selection[k]) for k in ("candidate_id", "structure_version_id", "metric_id")) + " |" for selection in audit["selections"]]
            lines += ["", "未选指标 ID：" + (", ".join(audit["unselected_metric_ids"]) or "无")]
        if recommendation is not None:
            lines += ["", "## 候选代表推荐", "",
                      "此排序用于后续计算规划，不代表材料性质更优。组成、空间群和晶胞规模档位等权覆盖；原子数仅为规模代理，不是实际计算费用。",
                      f"请求 {recommendation_limit} 个；合格代表 {recommendation['eligible_representative_count']} 个；实际推荐 {recommendation['selected_count']} 个。",
                      f"全量候选审计 SHA256：{recommendation['all_candidate_audit_sha256']}", "",
                      "| 顺序 | 候选 ID | 约化组成 | 空间群 | 输入原子数 | 新增覆盖类别 |", "|---|---|---|---|---|---|"]
            for row in sorted((r for r in recommendation["records"] if r["selected"]), key=lambda r: r["selection_rank"]):
                lines.append("| " + " | ".join(cell(value) for value in [row["selection_rank"], row["candidate_id"],
                    row["reduced_formula"], row["space_group_symbol"], row["site_count"],
                    ", ".join(row["selection_reason"]["new_category_coverage"]) or "同分按规模及ID选择"]) + " |")
            lines += ["", "满占位、组成完整与结构预检通过不证明稳定性、可合成性或催化性能。没有执行新生成、弛豫或DFT。未知分析结果已排除，所有排除原因保存在JSON证据中。"]
        md_path = folder / "report.md"
        md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return {"job_id": job_id, "report_path": str(md_path), "evidence_path": str(json_path),
                "execution_status": job["status"], "scientific_status": "unvalidated_candidates", "provenance": job["provenance"]}

    def doctor(self) -> dict:
        executable = "wsl.exe" if self.settings.backend == "wsl" else self.settings.command[0]
        return {"backend": self.settings.backend, "data_dir": str(self.store.root),
                "command_available": shutil.which(executable) is not None or Path(executable).is_file(),
                "readiness": "demo_available" if self.settings.backend == "demo" else "requires_generation_smoke_test",
                "seed_supported": self.settings.seed_supported, "models": cards(self.settings),
                "notice": "Executable discovery does not prove weights, CUDA or server readiness. API credentials belong to Harness, not this MCP service."}
