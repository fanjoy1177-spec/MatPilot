"""Export one real Harness recommendation case without hidden context or paths.

This is an evidence exporter only. It never contacts an API or executes tools.
Private exact tool/event bytes are hash-bound; the public copy retains actual
tool arguments/results after explicit path redaction, and visible messages only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def decode(value):
    if not isinstance(value, dict):
        return value
    if "selected_candidate_ids" in value:
        return value
    for key in ("structuredContent", "value"):
        if isinstance(value.get(key), dict):
            decoded = decode(value[key])
            if isinstance(decoded, dict) and "selected_candidate_ids" in decoded:
                return decoded
    content = value.get("content") or (value.get("value") or {}).get("content")
    if isinstance(content, list):
        text = "".join(c.get("text", "") for c in content if c.get("type") == "text")
        try:
            return json.loads(text)
        except (ValueError, TypeError):
            pass
    return value.get("value", value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-directory", required=True, type=Path)
    parser.add_argument("--ledger", required=True, type=Path)
    parser.add_argument("--fresh-comparison", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--warm-reconnect-record", type=Path)
    args = parser.parse_args()
    run = args.run_directory.resolve()
    output = args.output.resolve()
    transcript_path = output.with_suffix(".transcript.md")
    if output.exists() or transcript_path.exists():
        raise FileExistsError("Use new output names; do not overwrite an earlier acceptance record")
    record = load(run / "result.json")
    before = load(run / "cumulative-ledger.before.json")
    after = load(args.ledger)
    comparison = load(args.fresh_comparison)
    if record["collection_id"] != "mattergen_fresh_20261026" or record["expected_selection_count"] != 4:
        raise ValueError("This exporter requires the current fresh four-candidate case")
    if sha(run / "cumulative-ledger.before.json") != record["cumulative_ledger_before"]["sha256"]:
        raise ValueError("Original cumulative ledger snapshot hash mismatch")
    if after["records"][:len(before["records"])] != before["records"]:
        raise ValueError("Historical ledger records were not preserved")
    requests = record["requests"]
    request_ids = [r["id"] for r in requests]
    if len(set(request_ids)) != len(request_ids) or len(requests) > 6:
        raise ValueError("Repeated request identity or request ceiling exceeded")
    indexed_ledger = {r.get("id"): r for r in after["records"] if r.get("id")}
    for request in requests:
        if indexed_ledger.get(request["id"]) != request:
            raise ValueError("Current request is not identically bound to cumulative ledger")
        if request["status"] == "reserved":
            raise ValueError("Unsettled API reservation remains")
        if request["status"] == "usage_reported":
            u = request["usage"]
            cost = (2 * (u["inputTokens"] + u.get("cacheReadTokens", 0) + u.get("cacheWriteTokens", 0)) + 8 * u["outputTokens"]) / 1e6
        elif request["status"] == "reservation_retained":
            cost = (1048576 * 2 + 2048 * 8) / 1e6
        else:
            raise ValueError("Unrecognized request accounting status")
        if abs(cost - request["accounted_cny"]) > 1e-9:
            raise ValueError("API accounting cannot be independently reproduced")
    delta = sum(r["accounted_cny"] for r in requests)
    if delta > 5 + 1e-9 or abs(delta - record["outcome"]["api_accounted_cny"]) > 1e-9:
        raise ValueError("Single-case API cost mismatch or guard exceeded")
    allowed = set(record["constraints"]["allowed_tools"])
    if allowed != {"mcp__matpilot__get_capabilities", "mcp__matpilot__recommend_candidates"}:
        raise ValueError("Unexpected allowed tool set")
    tools = record["exact_tools"]
    if any(t["name"] not in allowed for t in tools):
        raise ValueError("An unapproved tool executed")
    recommendations = [t for t in tools if t["name"] == "mcp__matpilot__recommend_candidates"]
    actual = [decode(t["result"]) for t in recommendations]
    for call in recommendations:
        if call["arguments"].get("collection_id") != record["collection_id"] or call["arguments"].get("limit") != 4:
            raise ValueError("Recommendation was called for another collection or limit")
    matching = [r for r in actual if isinstance(r, dict) and r.get("selected_count") == 4
                and r.get("target_met") is True and len(set(r.get("selected_candidate_ids", []))) == 4]
    expected_ids = comparison["strategies"]["matpilot_diversity_k"]["candidate_ids"]
    recommendation_matches_cpu = bool(matching) and all(r["selected_candidate_ids"] == expected_ids for r in matching)
    turn_end = next((event for event in reversed(record["events"]) if event.get("type") == "turn/end"), None)
    actual_completed = bool(turn_end and turn_end.get("data", {}).get("reason", {}).get("kind") == "completed")
    auto_success = actual_completed and recommendation_matches_cpu and not record.get("denied_tools") and not record.get("quarantined")
    if bool(record["outcome"]["success"]) and not auto_success:
        raise ValueError("Controller success is unsupported by actual events, tools or frozen CPU result")
    redactions = []

    def clean(value, location="$"):
        if isinstance(value, list):
            return [clean(item, location + f"[{i}]") for i, item in enumerate(value)]
        if isinstance(value, dict):
            result = {}
            for key, item in value.items():
                if re.search(r"api[_-]?key|authorization|access[_-]?token|refresh[_-]?token|password|secret|replayState", key, re.I):
                    redactions.append({"location": location + "." + key, "kind": "credential_or_internal_state_omitted"})
                    continue
                result[key] = clean(item, location + "." + key)
            return result
        if isinstance(value, str):
            # Native MCP text blocks often embed a second JSON document.
            if value[:1] in "[{" and len(value) > 1:
                try:
                    nested = json.loads(value)
                    transformed = clean(nested, location + ".embedded_json")
                    return json.dumps(transformed, ensure_ascii=False) if transformed != nested else value
                except (ValueError, TypeError):
                    pass
            if re.match(r"^[A-Za-z]:[\\/]|^/mnt/[a-z]/|^/(?:home|root|Users)/", value):
                redactions.append({"location": location, "kind": "absolute_path_replaced"})
                return "<local-artifact-" + hashlib.sha256(value.encode()).hexdigest()[:12] + ">"
            replaced = re.sub(r"(?<![A-Za-z0-9])[A-Za-z]:[\\/][^\n\r\"<>]*|/mnt/[a-z]/[^\n\r\"<>]*|/(?:home|root|Users)/[^\n\r\"<>]*", "<local-artifact>", value)
            if replaced != value:
                redactions.append({"location": location, "kind": "embedded_absolute_path_replaced"})
            return replaced
        return value

    messages = []
    for event in record["events"]:
        if event.get("type") not in {"user/message", "assistant/message"}:
            continue
        data = event.get("data", {})
        message = data.get("message", data if event["type"] == "user/message" else {})
        if event["type"] == "user/message" and message.get("source", {}).get("kind") != "user":
            continue  # Runtime-context snapshots are not human messages.
        visible_content = [c for c in message.get("content", []) if c.get("type") not in {"reasoning", "thinking", "redacted_thinking"}]
        messages.append(clean({"event_type": event["type"], "turn": data.get("turn"), "step": data.get("step"),
            "message_id": message.get("id"), "role": message.get("role"), "content": visible_content,
            "content_text": "\n".join(c.get("text", "") for c in visible_content if c.get("type") == "text"),
            "usage": data.get("usage")}, "$.messages[" + str(len(messages)) + "]"))
    title_audit_path = run / "auxiliary-title-audit.json"
    title_events = sum(event.get("type") == "session/title-llm-request" for event in record["events"])
    title_audit = load(title_audit_path) if title_audit_path.exists() else None
    public = {"format": "matpilot-harness-recommendation-validation/v1",
        "scope": "one_real_llm_case_using_production_recommendation_tool_on_current_session_generated_candidates",
        "source_hashes": {"private_result_json": sha(run / "result.json"),
            "private_events_jsonl": sha(run / "events.jsonl"), "original_cumulative_ledger_snapshot": sha(run / "cumulative-ledger.before.json"),
            "current_cumulative_ledger": sha(args.ledger), "fresh_cpu_comparison": sha(args.fresh_comparison), "exporter_source": sha(__file__)},
        "collection_id": record["collection_id"], "user_request": record["user_request"],
        "model": record["model"], "constraints": record["constraints"], "started_at": record["started_at"], "finished_at": record["finished_at"],
        "validation": {"actual_turn_end_completed": actual_completed, "actual_recommendation_tool_calls": len(recommendations),
            "four_candidates_returned": bool(matching), "returned_ids_match_frozen_cpu_result": recommendation_matches_cpu,
            "historical_ledger_rows_unchanged": True, "request_accounting_recomputed": True,
            "executed_tools_within_allowlist": True, "operational_success": auto_success,
            "semantic_correctness": "not_independently_graded", "selected_candidate_ids": matching[-1]["selected_candidate_ids"] if matching else []},
        "outcome": clean(record["outcome"]), "messages": messages,
        "tool_calls": clean(tools), "denied_tools": clean(record.get("denied_tools", [])),
        "api_accounting": {"request_count": len(requests), "api_accounted_cny": delta,
            "cumulative_before_cny": sum(r["accounted_cny"] for r in before["records"]),
            "cumulative_after_cny": sum(r["accounted_cny"] for r in after["records"]),
            "requests": clean(requests), "basis": "All input, including cache-read/write, charged at 2 CNY/million; output at 8 CNY/million; failed/unknown usage retains full reservation. Project conservative accounting, not provider invoice."},
        "auxiliary_title_attempts": {"host_event_count": title_events, "audit": title_audit,
            "audit_sha256": sha(title_audit_path) if title_audit else None,
            "event_is_not_usage_receipt": True},
        "redactions": redactions,
        "limitations": ["One real AI-mediated operational demonstration, not a repeated with/without-plugin comparison.",
            "Model final prose is preserved without silently correcting errors; independent semantic grading was not conducted.",
            "Ranking and selected identities are verified against fixed CPU output, not measured material properties.",
            "No generation, relaxation or DFT is exposed to this agent; fresh structure generation is evidenced separately.",
            "Tool arguments and results are actual records; public strings may have personal absolute paths redacted, while private originals are hash-bound."]}
    if args.warm_reconnect_record:
        public["deployment_before_ai_case"] = {"first_capability_probe": clean(load(args.warm_reconnect_record)),
            "source_sha256": sha(args.warm_reconnect_record),
            "interpretation": "A capability query timed out after hot reload; a later query succeeded before this AI case. This earlier deployment wait is not included in the reported single-case wall time."}
    public["visible_prose_observations"] = []
    for message in messages:
        text = message["content_text"]
        if "1 Å 内无过近接触" in text:
            public["visible_prose_observations"].append({"kind": "unsupported_threshold_paraphrase",
                "model_quote": "1 Å 内无过近接触（阈值 0.5 Å）",
                "tool_evidence": "minimum_contact_angstrom=0.5; tool does not certify absence of contacts below 1 angstrom",
                "handling": "Original assistant text preserved; use the 0.5 angstrom tool policy, not the erroneous 1 angstrom paraphrase. This observation is not an independent overall semantic grade."})
    serialized = json.dumps(public, ensure_ascii=False, indent=2)
    if re.search(r"(?<![A-Za-z0-9])[A-Za-z]:[\\/]|/mnt/[a-z]/|C:\\\\Users|ASUS|Bearer\s+[A-Za-z0-9]", serialized):
        raise ValueError("Public export still contains a local path or possible credential")
    output.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# 本轮新候选：真实 Harness AI 推荐展示", "", "单次实际生产工具案例；不是有无插件对照统计。", "", "用户请求：", record["user_request"], ""]
    for message in messages:
        if message["role"] == "assistant" and message["content_text"]:
            lines += ["模型实际答复（保留原文，未替换成修正答案）：", "", message["content_text"], ""]
    lines += [f"实际 API 请求 {len(requests)} 次；保守核算 {delta:.6f} 元。", "",
        "实际推荐工具调用及返回候选身份已核对；未独立评分最后文字，也未评价稳定性、催化活性或合成可能性。", ""]
    transcript_path.write_text("\n".join(lines), encoding="utf-8")
    public["transcript"] = {"filename": transcript_path.name, "sha256": sha(transcript_path)}
    with output.open("x", encoding="utf-8") as handle:
        json.dump(public, handle, ensure_ascii=False, indent=2); handle.write("\n")
    print(json.dumps({"output": str(output), "sha256": sha(output), "validation": public["validation"],
        "request_count": len(requests), "api_accounted_cny": delta}, ensure_ascii=False))


if __name__ == "__main__":
    main()
