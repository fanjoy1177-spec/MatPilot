from pathlib import Path
import hashlib
import html
import json
import re
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, KeepTogether, Flowable, Table, TableStyle, PageBreak, Preformatted
from pypdf import PdfReader
import reportlab.lib.textsplit as textsplit
import reportlab.platypus.paragraph as paragraph_module

# Include full-width Chinese punctuation in the renderer's line-start prohibition.
textsplit.ALL_CANNOT_START += '，；：！？）》】」』”’'
paragraph_module.ALL_CANNOT_START = textsplit.ALL_CANNOT_START

BASE = Path(__file__).resolve().parent
OUT = BASE / 'output' / 'pdf'
OUT.mkdir(parents=True, exist_ok=True)
FONT = Path('C:/Windows/Fonts')
for name, file, index in [('FangSong','simfang.ttf',0), ('Song','simsun.ttc',0), ('Hei','simhei.ttf',0), ('TNR','times.ttf',0), ('YaHei','msyh.ttc',0), ('YaHeiBold','msyhbd.ttc',0)]:
    pdfmetrics.registerFont(TTFont(name, str(FONT / file), subfontIndex=index))

WIDTH = A4[0] - 40*mm
official_styles = {
    'title': ParagraphStyle('title',fontName='Hei',fontSize=16,leading=22,alignment=TA_CENTER,spaceAfter=14,keepWithNext=True),
    'h2': ParagraphStyle('h2',fontName='Hei',fontSize=14,leading=18,spaceBefore=10,spaceAfter=7,keepWithNext=True),
    'h3': ParagraphStyle('h3',fontName='Hei',fontSize=12,leading=16,spaceBefore=7,spaceAfter=5,keepWithNext=True),
    'body': ParagraphStyle('body',fontName='FangSong',fontSize=12,leading=13.8,firstLineIndent=24,alignment=TA_JUSTIFY,wordWrap='CJK',spaceAfter=6,splitLongWords=True,allowWidows=0,allowOrphans=0),
    'flat': ParagraphStyle('flat',fontName='FangSong',fontSize=12,leading=13.8,alignment=TA_LEFT,wordWrap='CJK',spaceAfter=6),
    'caption': ParagraphStyle('caption',fontName='Song',fontSize=9,leading=12,alignment=TA_CENTER,spaceBefore=5,spaceAfter=8,wordWrap='CJK'),
    'note': ParagraphStyle('note',fontName='FangSong',fontSize=10.5,leading=13,spaceAfter=8,wordWrap='CJK'),
}
official_styles['table']=ParagraphStyle('table',parent=official_styles['flat'],spaceAfter=0,firstLineIndent=0)
official_styles['tabletitle']=ParagraphStyle('tabletitle',parent=official_styles['caption'],fontName='FangSong',fontSize=12,leading=13.8,keepWithNext=True)
official_styles['reference']=ParagraphStyle('reference',parent=official_styles['flat'])
reading_styles={k:ParagraphStyle('read_'+k,parent=v) for k,v in official_styles.items()}
for st in reading_styles.values():
    st.fontName='YaHei'
    st.textColor=colors.HexColor('#111111')
for k in ['body','flat']:
    reading_styles[k].fontSize=13
    reading_styles[k].leading=20
    reading_styles[k].spaceAfter=8
    reading_styles[k].firstLineIndent=0
    reading_styles[k].alignment=TA_LEFT
for k,size,leading in [('title',18,26),('h2',15,21),('h3',13,19)]:
    reading_styles[k].fontName='YaHeiBold'
    reading_styles[k].fontSize=size
    reading_styles[k].leading=leading
reading_styles['h2'].spaceBefore=13
reading_styles['h3'].spaceBefore=9
reading_styles['caption'].fontSize=10
reading_styles['caption'].leading=14
reading_styles['note'].fontSize=11
reading_styles['note'].leading=16
reading_styles['table'].fontSize=12
reading_styles['table'].leading=18
reading_styles['tabletitle'].fontSize=11
reading_styles['tabletitle'].leading=16
reading_styles['reference'].fontSize=11
reading_styles['reference'].leading=14.5
reading_styles['reference'].spaceAfter=4
styles=official_styles
is_reading=False

def rich(text):
    if is_reading:
        return html.escape(text)
    # Official edition retains the stipulated Western and Chinese typefaces.
    chunks = re.split(r'([\x20-\x7e]+)', text)
    return ''.join('<font name="TNR">'+html.escape(c)+'</font>' if c and all(ord(a)<128 for a in c) else html.escape(c) for c in chunks)

FLOW_LABELS=[('提出需求','用户说明目标'),('准备计划','AI提案 插件核对'),('审阅确认','用户决定执行'),('运行跟踪','状态 预算 输出'),('候选核对','按原要求检查'),('交付结果','结构 报告 依据')]
FLOW_NOTE='同一份要求连接计划、执行与结果；用户决定下一步研究'

class Workflow(Flowable):
    def __init__(self):
        super().__init__()
        self.width=WIDTH
        self.height=88
    def draw(self):
        c=self.canv
        w=73
        gap=(WIDTH-6*w)/5
        for i,(a,b) in enumerate(FLOW_LABELS):
            x=i*(w+gap)
            c.setFillColor(colors.HexColor('#f3f5f6'))
            c.setStrokeColor(colors.HexColor('#394958'))
            c.setLineWidth(.6)
            c.roundRect(x,29,w,43,3,stroke=1,fill=1)
            c.setFillColor(colors.black)
            c.setFont('YaHei' if is_reading else 'Song',9)
            c.drawCentredString(x+w/2,55,a)
            c.setFont('YaHei' if is_reading else 'Song',8)
            c.drawCentredString(x+w/2,39,b)
            if i<5:
                c.line(x+w+1,50,x+w+gap-1,50)
                c.line(x+w+gap-4,53,x+w+gap-1,50)
                c.line(x+w+gap-4,47,x+w+gap-1,50)
        c.setFont('YaHei' if is_reading else 'Song',9)
        c.drawCentredString(WIDTH/2,10,FLOW_NOTE)


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('TNR',9)
    canvas.drawCentredString(A4[0]/2,14*mm,str(doc.page))
    canvas.restoreState()

CAPTIONS = [
    '图1 从提出需求到交付结果的任务流程',
    '图2 历史MatterGen真实运行所得候选结构（Fe2Ni4O8）',
    '已完成文件解析及组成、基本几何检查；析氧活性、稳定性及可合成性未验证。'
]

def flow_for_markdown(text, application=False):
    flow=[]
    for block in text.strip().split('\n\n'):
        if block.startswith('# '):
            title=block[2:]
            if application:
                title='材策申报书正文'
            flow.append(Paragraph(rich(title),styles['title']))
            if application:
                flow.append(Paragraph('以下为官方申报表三个栏目使用的正文，人员信息与签章另在原表完成。',styles['note']))
        elif block=='<!-- FIGURE_WORKFLOW -->':
            flow.append(KeepTogether([Workflow(),Paragraph(rich(CAPTIONS[0]),styles['caption'])]))
        elif block=='<!-- FIGURE_CANDIDATE -->':
            img=Image(str(BASE/'assets/historical_candidate.png'),width=260,height=260*834/865)
            img.hAlign='CENTER'
            intro=flow.pop()
            flow.append(KeepTogether([intro,img,Paragraph(rich(CAPTIONS[1])+'<br/>'+rich(CAPTIONS[2]),styles['caption'])]))
        elif block.startswith('```'):
            code='\n'.join(block.splitlines()[1:-1])
            code_style=ParagraphStyle('code',fontName='Courier',fontSize=8,leading=11,spaceBefore=4,spaceAfter=8)
            flow.append(KeepTogether([Preformatted(code,code_style,maxLineLength=91,splitChars=' /')]))
        elif block.startswith('### '):
            flow.append(Paragraph(rich(block[4:]),styles['h3']))
        elif block.startswith('## '):
            if block.startswith(('## 第二步','## 命令行')):
                flow.append(PageBreak())
            if False:
                flow.append(PageBreak())
            flow.append(Paragraph(rich(block[3:]),styles['h2']))
        elif re.match(r'^表\d+ ',block):
            flow.append(Paragraph(rich(block),styles['tabletitle']))
        elif block.startswith('| '):
            rows=[]
            for row in block.splitlines():
                cells=[cell.strip() for cell in row.strip('|').split('|')]
                if all(re.fullmatch(r'[-: ]+',x) for x in cells):
                    continue
                rows.append([Paragraph(rich(cell),styles['table']) for cell in cells])
            widths=([.13,.18,.69] if '候选' in rows[0][0].text else [.14,.43,.43]) if len(rows[0])==3 else [.36,.64]
            table=Table(rows,colWidths=[WIDTH*x for x in widths],repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([
                ('LINEABOVE',(0,0),(-1,0),1,colors.black),
                ('LINEBELOW',(0,0),(-1,0),.6,colors.black),
                ('LINEBELOW',(0,-1),(-1,-1),1,colors.black),
                ('VALIGN',(0,0),(-1,-1),'TOP'),
                ('TOPPADDING',(0,0),(-1,-1),7),
                ('BOTTOMPADDING',(0,0),(-1,-1),7),
                ('LEFTPADDING',(0,0),(-1,-1),6),
                ('RIGHTPADDING',(0,0),(-1,-1),6),
            ]))
            caption=flow.pop()
            group=[caption,table,Spacer(1,8)]
            if flow and 'h2' in flow[-1].style.name:
                group.insert(0,flow.pop())
            elif len(flow)>1 and isinstance(flow[-2],Paragraph) and 'h2' in flow[-2].style.name:
                intro=flow.pop(); heading=flow.pop(); group=[heading,intro]+group
            flow.append(KeepTogether(group))
        elif block.startswith('['):
            rendered=rich(block)
            rendered=rendered.replace(' https://','<br/>https://')
            flow.append(Paragraph(rendered,styles['reference']))
        else:
            st=styles['flat'] if block.startswith(('关键词','[','拟用作品名称','建议类别')) else styles['body']
            paragraph=Paragraph(rich(block.replace('\n',' ')),st)
            flow.append(KeepTogether([paragraph]) if block.startswith('以镍铁氧体系为例') else paragraph)
    return flow

body=(BASE/'01_作品说明书正文.md').read_text(encoding='utf-8')
app=(BASE/'02_申报书正文.md').read_text(encoding='utf-8')
body_output=OUT/'MatPilot_作品说明书_清晰阅读版.pdf'
official_output=OUT/'MatPilot_作品说明书_匿名提交版.pdf'
app_output=OUT/'MatPilot_申报书三栏正文.pdf'
for source,dest,is_app,read_mode in [(body,body_output,False,True),(body,official_output,False,False),(app,app_output,True,True)]:
    is_reading=read_mode
    styles=reading_styles if read_mode else official_styles
    doc=SimpleDocTemplate(str(dest),pagesize=A4,rightMargin=20*mm,leftMargin=20*mm,topMargin=25*mm,bottomMargin=25*mm,title='材策作品说明书' if not is_app else '材策申报书正文',author='',subject='材料计算任务规划与证据核验',creator='')
    doc.build(flow_for_markdown(source,is_app),onFirstPage=footer,onLaterPages=footer)

def clean_count(s):
    s=re.sub(r'<!--.*?-->','',s,flags=re.S)
    s=re.sub(r'^#+\s*','',s,flags=re.M)
    return len(re.sub(r'\s','',s))

abstract=body.split('## 摘要')[1].split('关键词')[0]
sections={}
for part in app.split('\n## ')[1:]:
    title,txt=part.split('\n',1)
    title=title.split('（')[0]
    if title in ['作品摘要','作品的科学性先进性','作品推广应用的可行性分析']:
        sections[title]=clean_count(txt)
quality={
    'date':'2026-10-23',
    'count_method':'Conservative non-whitespace character count including punctuation and Western characters; full body includes figure captions and visible workflow labels.',
    'description_characters':clean_count(body)+sum(clean_count(x) for x in CAPTIONS)+sum(clean_count(a+b) for a,b in FLOW_LABELS)+clean_count(FLOW_NOTE),
    'abstract_characters':clean_count(abstract),
    'application_characters':sections,
    'page_geometry':{'page':'A4','top_mm':25,'bottom_mm':25,'left_mm':20,'right_mm':20},
    'revision':8,
    'reading_body_font':'Microsoft YaHei 13pt, 20pt leading; bold YaHei headings; embedded fonts',
    'official_body_font':'FangSong 12pt, Times New Roman for Western text, 13.8pt leading; embedded fonts',
    'same_content_in_two_description_editions':True,
    'files':[],
    'visual_review':'pending',
    'submission_state':'Anonymous description and application text; official application identity/signature/stamps remain to be completed in original form.',
}
assert quality['description_characters']<5000
assert quality['abstract_characters']<400
assert sections['作品摘要']<=500 and sections['作品的科学性先进性']<=500 and sections['作品推广应用的可行性分析']<=200
description_texts=[]
guide_output=OUT/'MatPilot_安装与使用说明.pdf'
is_reading=True
styles=reading_styles
guide=(BASE/'03_安装与使用说明.md').read_text(encoding='utf-8')
SimpleDocTemplate(str(guide_output),pagesize=A4,rightMargin=20*mm,leftMargin=20*mm,topMargin=25*mm,bottomMargin=25*mm,title='MatPilot安装与使用说明',author='',creator='').build(flow_for_markdown(guide),onFirstPage=footer,onLaterPages=footer)
for file in [body_output,official_output,app_output,guide_output]:
    r=PdfReader(file)
    txt='\n'.join(p.extract_text() or '' for p in r.pages)
    if file in [body_output,official_output]:
        forbidden=['ASUS','fanjoy','C:/','C:\\','申请者姓名','学校全称']
        assert not any(x in txt for x in forbidden)
        assert not (r.metadata.author or '')
        description_texts.append(re.sub(r'\s','',re.sub(r'^\d+\s*$','',txt,flags=re.M)))
    quality['files'].append({'name':file.name,'pages':len(r.pages),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
    (BASE/'qa').mkdir(exist_ok=True)
    (BASE/'qa'/f'{file.stem}.txt').write_text(txt,encoding='utf-8')
# Both editions are built from the identical source and figures; pagination can differ.
assert description_texts[0]==description_texts[1], 'Description editions differ in extracted content'

(BASE/'qa/quality_checks.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(quality,ensure_ascii=False,indent=2))
