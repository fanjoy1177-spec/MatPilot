"""Rebuild the offline competition evidence view from existing public records.

Standard library only. Does not import MatPilot, execute tools, access accounts,
call an LLM, or run a materials model. All outputs stay beside this script.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import zipfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def result_body(tool):
    result = tool["result"]
    if isinstance(result.get("value"), dict):
        return result["value"]
    return json.loads("".join(part["text"] for part in result.get("content", []) if part["type"] == "text"))


def main():
    sources = []

    def read(relative):
        raw = (ROOT / relative).read_bytes()
        sources.append({"path": relative, "sha256": digest(raw)})
        return raw

    deployment = json.loads(read("artifacts/v08-deployment-validation.json"))
    comparison = json.loads(read("artifacts/metric-screening-cpu-comparison.json"))
    repair_source = read("tests/test_repairs.py")
    tree = ast.parse(repair_source.decode("utf-8"))
    function = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)
                    and node.name == "test_numeric_target_retained_and_structural_requirement_remains_a_hard_check")
    request_node = next(node.value for node in function.body if isinstance(node, ast.Assign)
                        and any(isinstance(target, ast.Name) and target.id == "request" for target in node.targets))
    request = ast.literal_eval(request_node)
    dump(HERE / "request-conflict.json", request)
    dump(HERE / "demo-config.json", {"backend": "demo", "real_compute_enabled": False,
                                      "max_samples": 4, "data_dir": "local-demo-data"})

    archive_relative = "releases/0.2.0.dev5/MatPilot_development_review_r3.zip"
    archive_bytes = read(archive_relative)
    runs = []
    selected_check = None
    with zipfile.ZipFile(ROOT / archive_relative) as archive:
        all_documents = []
        for name in archive.namelist():
            if "/runs/" not in "/" + name or not name.endswith(".json"):
                continue
            raw = archive.read(name)
            document = json.loads(raw)
            all_documents.append(document)
            if document["run"]["task_id"] != "D0101":
                continue
            run = document["run"]
            tools = document["visible"]["tool_records"]
            sources.append({"path": archive_relative + "!" + name, "sha256": digest(raw)})
            final_status = result_body(next(tool for tool in reversed(tools) if tool["name"] == "status"))
            runs.append({"run_id": run["run_id"], "group": run["group"], "tool_calls": len(tools),
                         "tool_names": [tool["name"] for tool in tools], "sampling_attempts": final_status["attempts_used"],
                         "wall_seconds": run["wall_seconds"], "api_accounted_cny": run["api_accounted_cny"],
                         "correctness": run["correctness"], "human_active_seconds": run["human_active_seconds"]})
            if run["group"] == "M":
                selected_check = result_body(next(tool for tool in tools if tool["name"] == "check_candidates"))
        aggregate = []
        for group in ("U", "U+", "M"):
            rows = [doc for doc in all_documents if doc["run"]["group"] == group]
            assert len(rows) == 12
            aggregate.append({"group": group, "runs": len(rows),
                              "wall_seconds_sum": sum(doc["run"]["wall_seconds"] for doc in rows),
                              "api_accounted_cny_sum": sum(doc["run"]["api_accounted_cny"] for doc in rows),
                              "tool_calls": sum(len(doc["visible"]["tool_records"]) for doc in rows)})

    assert deployment["version"] == "0.2.0.dev8" and deployment["passed"] is True
    assert deployment["real_scientific_computation"] is False and deployment["api_calls"] == 0
    assert {r["group"]: r["tool_calls"] for r in runs} == {"U": 18, "U+": 18, "M": 8}
    assert all(r["sampling_attempts"] == 4 for r in runs)
    assert selected_check["valid_candidate_count"] == 3 and selected_check["unique_valid_candidate_count"] == 1
    current = comparison["versions"]["candidate_source"]
    assert current["declared_version"] == "0.2.0.dev8"
    cases = current["cases"]
    assert [cases[k]["registered_mcp"]["status"] for k in
            ("default_multiple_metrics", "select_1_1", "select_1_6")] == ["unknown", "pass", "fail"]

    # Strict whitelist: no system prompt, headers, session IDs or raw event stream.
    record_fields = ("candidate_id", "formula", "parse_valid", "composition_match",
                     "equivalent_to_candidate_id", "structural_equivalence_status",
                     "basic_checks_pass", "all_hard_requirements_pass", "research_goals_verified", "requirement_checks")
    assert sum(r["all_hard_requirements_pass"] is True for r in selected_check["records"]) == 3
    assert next(r for r in selected_check["records"] if r["candidate_id"] == "c_c")["all_hard_requirements_pass"] is False
    packet = {
        "format": "matpilot-competition-offline-evidence/v1",
        "display_kind": "existing_record_view_not_live_harness_or_chat",
        "new_api_calls": 0, "new_material_model_runs": 0,
        "sources": sources,
        "planning": {"fixture_request": request, "fixture_request_source": "tests/test_repairs.py",
                     "request_notice": "Hand-authored reproducible input; not a new LLM extraction or live output.",
                     "desktop_conflict_blocked": deployment["conflict_blocked"],
                     "desktop_repair_summary": deployment["reviewable_repair"]},
        "desktop_demo": {"version": deployment["version"], "backend": deployment["backend"],
                         "tool_count": deployment["tool_count"], "cases": deployment["cases"]},
        "historical_D0101": {"version": "0.2.0.dev5", "date": "2026-10-22", "mode": "development_cpu_replay",
                             "llm_called_in_original_run": True, "material_model_called": False,
                             "runs": runs, "records": [{k: r.get(k) for k in record_fields} for r in selected_check["records"]],
                             "candidate_records": len(selected_check["records"]),
                             "valid_candidate_count": selected_check["valid_candidate_count"],
                             "unique_valid_candidate_count": selected_check["unique_valid_candidate_count"],
                             "full_12_task_aggregate": aggregate},
        "metric_selection": {"desktop_workflow": deployment["metric_selection_workflow"],
                             "baseline_version": comparison["versions"]["frozen_release"]["declared_version"],
                             "version": current["declared_version"],
                             "property": "dft_band_gap", "unit": "eV", "conditioning_target": 1.1,
                             "value_notice": "Synthetic values; pass/fail is the software check for the selected evidence only, not material qualification.",
                             "cases": {k: cases[k] for k in ("default_multiple_metrics", "select_1_1", "select_1_6", "wrong_binding", "reports_coexist")},
                             "accounting_before": current["accounting_before"], "accounting_after": current["accounting_after"]},
    }
    # Keep the complete already-public artifacts alongside the whitelist projection.
    source_dir = HERE / "evidence"
    source_dir.mkdir(exist_ok=True)
    for name in ("v08-deployment-validation.json", "metric-screening-cpu-comparison.json"):
        (source_dir / name).write_bytes((ROOT / "artifacts" / name).read_bytes())
    dump(HERE / "evidence-snapshot.json", packet)
    template = (HERE / "page-template.html").read_text(encoding="utf-8")
    inline = json.dumps(packet, ensure_ascii=False).replace("<", "\\u003c")
    (HERE / "index.html").write_text(template.replace("__EVIDENCE_JSON__", inline), encoding="utf-8")
    generated = ["index.html", "evidence-snapshot.json", "request-conflict.json", "demo-config.json",
                 "evidence/v08-deployment-validation.json", "evidence/metric-screening-cpu-comparison.json"]
    dump(HERE / "manifest.json", {"scope": "offline_evidence_projection_only", "inputs": sources,
                                 "outputs": [{"path": name, "sha256": digest((HERE / name).read_bytes())} for name in generated],
                                 "new_api_calls": 0, "new_material_model_runs": 0})
    print(json.dumps({"generated_files": len(generated) + 1, "D0101_tool_counts": {r["group"]: r["tool_calls"] for r in runs},
                      "source_assertions": "passed", "api_calls": 0, "material_model_runs": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
