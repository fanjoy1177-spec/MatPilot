# MatPilot v1.1 候选 v2 待审核包

这是 dev7 发布后补齐的审核交付材料，不是新题库版本，也不是已批准或已评分结果。旧 20261022 包原样保留。
你可以之后自行阅读、提出意见；本次不要求老师现在做题。正式研究所需的独立材料审核、未见新题与真实运行仍未完成。

建议阅读顺序：

1. [三项修订对照](三项修订对照.md)：先看 T0601、T0205、T0305 的原文、改后和理由。
2. [36 题一览](36题一览.md)：完整题干、固定回复、待审标准答案和合成情境。
3. 在 review-notes.to-complete.json 记录意见；decision 和检查项在实际审核前保持 null。
4. 题库和事实分别是 suite.for-review.json、fixtures.for-review.json；sources 保留修订前后原始字节，evidence 是既有 CPU 覆盖证据。

本包审核题目和 fixture，不评价 LLM 答复。execution_grade 保持 null；没有产生人工成绩。
review.to-complete.json 和 fixture-review.to-complete.json 是现有工具生成的未批准模板：approved=false、independent_of_implementation=false，身份、日期、资格和意见均为空。不要为了让程序运行而改成 true。
后续修改题干、澄清、gold 或事实后，相关旧哈希及批准失效，应通过现有 review-packet 工具重新生成；用户一般意见不自动等于独立材料审核。

不能把本包或 gold、task_bindings、probe 等审核信息交给运行中的 LLM。正式运行只导出题干、工具可观察情境和按条件释放的澄清。
36 个情境的 CPU 核验不是 36 题答对；指标和结构均为合成材料，没有新增 API 或真实材料计算。

来源与完整性：

- source-provenance.json 区分文件字节 SHA256 和题库规范化 JSON SHA256，并记录旧包身份及来源发布提交。
- HASHES.json 和 SHA256SUMS.txt 给出本包文件字节哈希；哈希不证明科学结论或审核已发生。
- sources/candidate_revision_proposal.v2.json 保存三项修订完整 before/after 和原始来源哈希。
