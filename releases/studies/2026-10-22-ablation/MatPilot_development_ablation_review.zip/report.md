# MatPilot 开发对照：待用户审核

这里只汇总可核验的执行过程、请求费用与墙钟时间。尚未判断任务正确率、材料性质或提速。

计划 12 次；本次选择 12 次；未选择 0 次。
宿主回合正常结束 12 次；失败 0 次；超时 0 次；预算停止 0 次；缺失 0 次；中断/缺最终记录 0 次；审计不通过 0 次。

正常结束不等于任务正确。每条原始失败、缺失和异常均保留，费用上界不冒充实际账单。

| 组别 | 计划 | 选择 | 正常结束 | 失败/超时/预算停止 | 缺失/中断/无效 | 已核对 API 金额（元） | 已记录运行墙钟（秒） |
|---|---:|---:|---:|---:|---:|---:|---:|
| U | 0 | 0 | 0 | 0 | 0 | 0.000000 | 0.000 |
| U+ | 0 | 0 | 0 | 0 | 0 | 0.000000 | 0.000 |
| M | 4 | 4 | 4 | 0 | 0 | 0.965612 | 65.555 |
| M_without_mapping | 4 | 4 | 4 | 0 | 0 | 1.297414 | 58.161 |
| M_without_evidence | 4 | 4 | 4 | 0 | 0 | 1.171118 | 56.677 |

## 逐次记录

| 运行 | 执行记录状态 | 待审记录 |
|---|---|---|
| D0101--M_without_mapping--1 | completed | [完整题干、答复与工具记录](runs/D0101--M_without_mapping--1.md) |
| D0101--M_without_evidence--1 | completed | [完整题干、答复与工具记录](runs/D0101--M_without_evidence--1.md) |
| D0101--M--1 | completed | [完整题干、答复与工具记录](runs/D0101--M--1.md) |
| D0201--M_without_mapping--1 | completed | [完整题干、答复与工具记录](runs/D0201--M_without_mapping--1.md) |
| D0201--M_without_evidence--1 | completed | [完整题干、答复与工具记录](runs/D0201--M_without_evidence--1.md) |
| D0201--M--1 | completed | [完整题干、答复与工具记录](runs/D0201--M--1.md) |
| D0502--M_without_mapping--1 | completed | [完整题干、答复与工具记录](runs/D0502--M_without_mapping--1.md) |
| D0502--M_without_evidence--1 | completed | [完整题干、答复与工具记录](runs/D0502--M_without_evidence--1.md) |
| D0502--M--1 | completed | [完整题干、答复与工具记录](runs/D0502--M--1.md) |
| D0202--M_without_mapping--1 | completed | [完整题干、答复与工具记录](runs/D0202--M_without_mapping--1.md) |
| D0202--M--1 | completed | [完整题干、答复与工具记录](runs/D0202--M--1.md) |
| D0202--M_without_evidence--1 | completed | [完整题干、答复与工具记录](runs/D0202--M_without_evidence--1.md) |

## 审核边界

请逐题核对需求是否保留、动作是否合理、候选是否对应、结论是否有证据。本包不预填通过意见。
API 请求历时不替代人工操作时间；运行状态不能用于宣称正确率、材料性能或相对提速。公开副本已排除系统、思考、凭据和本地绝对路径，原始轨迹保持不变。

机器可读计数、身份哈希、异常原因及分组计量见 [metrics.json](metrics.json)。
