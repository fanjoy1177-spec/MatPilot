# Harness 0.2.0-dev.12 / core 0.2.0.dev14 acceptance

2026-11-01. These are separate version axes. This package contains the merged
core dev14 wheel, and its recipe verifies both the wheel checksum and the exact
12-tool MCP contract. The deployment recipe uses a new managed environment ID.
MatterGen code, dependency locks, and checkpoint pins are unchanged.

The current release is checked through package integrity, the existing 13
deployment/download tests, Harness regression tests, and actual demo-mode MCP
initialization directly from the built wheel. This verifies local packaging and
protocol compatibility in the existing Windows Python environment. It does not
constitute a new Linux/WSL installation, CUDA/model check, real generation, or
fresh-machine acceptance of dev14. No existing user configuration is changed.

The merged core previously passed 427 of 437 Python checks, with 10 documented
skips, plus 32 targeted formal-source interface checks. See
`docs/validation_summary_20261101.md` for scientific evidence and its limits.

## Historical deployment evidence, retained verbatim

The following record concerns Harness dev11 / core dev8 on 2026-10-25. It is
historical evidence of the deployment mechanism, not a dev14 installation result.

# 材策 dev11 环境部署验收

2026-10-25。本开发版将环境检查、固定版本安装、失败恢复、分层验证与自动连接集成到材策插件；Python 核心继续为 0.2.0.dev8。安装包需联网。

## 已验证

- 13 项部署/下载自动化测试通过：无需 Python 的检查、GPU 缺失、架构/工具不符、计划篡改拦截、重复启动和互斥、依赖失败恢复、已退出进程识别、真实计算授权、下载截断和损坏文件等。
- 在 DeepSeek Harness 0.2.1-rc.2 实际工具运行时注册七个部署工具；手动 Python 路径设置为不可用时，检查工具仍能调用。
- 在 Windows WSL2 / Linux x86_64 / NVIDIA GPU 上，从新的受管目录安装 Python 3.10.19、材策核心及独立 MatterGen 1.0.3 环境。系统 WSL、驱动和基础命令此前已存在，不宣称从空白操作系统部署。
- PyTorch 2.2.1+cu121 能完成实际 CUDA 张量分配；模型文件与配置 SHA256 核对通过；官方 MCP 客户端完成初始化、九工具发现与能力查询。
- 一个候选真实生成完成，取得可解析 CIF，基础检查通过，证据与报告生成。不证明稳定性、可合成性、催化或其他材料性能。
- 经插件的激活工具自动接入同一 Harness 工具运行时，九个材料工具可见且能力查询成功；无需手动复制 Python/config 路径，日常真实计算保持关闭。

公开汇总见 `benchmarks/deployment/validation-summary.json`。原始事件、任务、环境详情、CIF 和报告保留在开发工作区 `artifacts/deployment/`，不随公开发行包分发。真实生成记录为 `mattergen_execution`，演示夹具没有计入成功候选。

## 失败也保留

1. PyPI 上 MatterGen 1.0.3 的旧依赖元数据与官方修复提交不一致。采用固定官方提交构建 wheel、锁定兼容依赖；源码及许可证保留，未修改生成模型。
2. WSL NAT 下 Windows localhost 代理不可直用。安装任务使用临时鉴权、来源/域名受限的转发，不关闭 TLS 校验或修改全局代理。
3. 第一次联网安装在 Hugging Face 下载阶段因 TLS 关闭异常失败。同一任务恢复，复用 Python/依赖和下载缓存，完成安装。补充了“传输异常但文件 SHA256 完整匹配”的安全恢复测试。
4. 第一轮真实验证因检查点清单缺少官方 config.yaml、目录结构未保留而失败。修正清单和复制结构后，新一轮单候选验证通过。两次验证记录均保留，失败任务未伪装成成功，也未通过恢复重复采样。
5. 既有 Python 回归初次执行 263 项，9 项按平台跳过，研究准备类因 Windows Git 长路径限制初始化失败。仅对隔离检出启用 `core.longpaths` 后，该类 12 项复测通过。远程 Linux CI 另行完整检查，不能把初次运行写成全通过。

## 原流程对照与未测部分

`benchmarks/deployment/baseline/` 归档 dev10 原部署说明/入口和固定版官方 README；`docs/deployment.md` 列出逐环节差异；`benchmarks/deployment/protocol.md` 与记录模板规定 A 人工、B 通用 Harness、C 材策的同条件比较。

本轮是开发联调：首次安装、失败恢复、修改配方后的缓存重装分别留档。人工主动时间、独立用户成功率、API 节省和提速比例均未测，保持空值。不把提示词、插件形式、上游生成模型或一次成功样本宣称为科研首创。

本版未自动安装 WSL/驱动、未验证 macOS/ARM、远程 GPU 自动部署或所有代理类型；尚未做付费 Harness 自然语言安装对话和新版 Electron 页面完整端到端验收。系统前置条件不足会给出操作说明，不静默降级 demo。

下载 ZIP 后按 INSTALL.md 使用；SHA256SUMS.txt 用于核对包。该版本作为开发预发布提供，历史 dev10 和原手动流程仍保留。
